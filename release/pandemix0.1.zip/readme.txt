If all you need is Pandemix, include pandemix-min.js, pandemix.css and sprites.png in your HTML. However, Pandemix depends on D3 and Crossfilter for most things and Leaflet for maps, so you should include a copy of those as well. 
allMin.js includes pandemix-min as well as a version of the 3 other librariers it depends on.
